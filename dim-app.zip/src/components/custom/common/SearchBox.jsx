import React, { Component } from 'react';
import { Button, Col, DatePicker, Form, Icon, Input, Row, Select } from 'antd';
import SearchHint from './SearchHint';
import { getAuthority } from '../../../utils/authority';
import { applyPolicy } from '../../../utils/utils';

@Form.create()
class SearchBox extends Component {
  state = {
    expand: false,
  };
  // To generate mock Form.Item
  getFields() {
    const { expand } = this.state;
    const {
      form: { getFieldDecorator },
      searchMapper: searchFields,
    } = this.props;

    return searchFields.map(searchField => {
      const { label, name, secondary, required, message, validator } = searchField;
      const rule = { required, message };
      if (validator) rule.validator = validator;
      return (
        <Col span={8} key={name} style={{ display: !secondary || expand ? 'block' : 'none' }}>
          <Form.Item label={label}>
            {getFieldDecorator(name, {
              rules: [rule],
            })(this.concretizeItem(searchField))}
          </Form.Item>
        </Col>
      );
    });
  }

  concretizeItem(item) {
    const { name, type } = item;
    switch (type) {
      case 'date':
        return <DatePicker name={name} />;
      case 'select':
        this.buildSelect(item);
      default:
        return <Input name={name} />;
    }
  }

  buildSelect(item) {
    const { defaultValue, label, name, options } = item;
    return (
      <Select defaultValue={defaultValue} label={label} name={name}>
        {options.map(option => (
          <Select.Option value={option}>{option}</Select.Option>
        ))}
      </Select>
    );
  }

  hasSecondaryFields = () => {
    const { searchMapper: searchFields } = this.props;
    for (let i = 0; i < searchFields.length; i++) if (searchFields[i].secondary) return true;

    return false;
  };

  handleSearch = e => {
    const {
      form: { validateFields },
      onSearch,
    } = this.props;
    e.preventDefault();
    validateFields((err, values) => {
      if (!err) onSearch(values);
    });
  };

  handleReset = () => {
    const {
      form: { resetFields },
    } = this.props;
    resetFields();
  };

  toggle = () => {
    const { expand } = this.state;
    this.setState({ expand: !expand });
  };

  render() {
    const { expand } = this.state;
    const { method, hintMessage } = this.props;
    return (
      <Form
        method={method}
        style={{
          padding: '24px',
          background: '#fbfbfb',
          border: '1px solid #d9d9d9',
          borderRadius: '6px',
        }}
        onSubmit={this.handleSearch}
      >
        <Row gutter={24}>{this.getFields()}</Row>
        <Row>
          <Col span={24} style={{ textAlign: 'right' }}>
            <a
              style={{
                marginLeft: 8,
                fontSize: 12,
                display: this.hasSecondaryFields() ? 'block' : 'none',
                marginBottom: '10px',
              }}
              onClick={this.toggle}
            >
              {`Recherche avancée...`}
              <Icon type={expand ? 'up' : 'down'} />
            </a>
            <SearchHint data={hintMessage}>
              <Button type="primary" htmlType="submit">
                Lancer la recherche
              </Button>
            </SearchHint>
            <Button style={{ marginLeft: 8 }} onClick={this.handleReset}>
              Effacer
            </Button>
          </Col>
        </Row>
      </Form>
    );
  }
}

export default SearchBox;
