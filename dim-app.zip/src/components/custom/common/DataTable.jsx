import React, { PureComponent } from 'react';
import { Table } from 'antd';
import { applyPolicy } from '../../../utils/utils';

export default class DataTable extends PureComponent {
  render() {
    const {
      dataSource: { metadata, data, pagination },
      actions,
    } = this.props;
    const columns = metadata.map(column => {
      return {
        ...column,
        title: column.label,
        dataIndex: column.name,
        key: column.dataIndex,
        sorter: (a, b) => (a.statut > b.statut ? 1 : -1),
      };
    });
    if (actions)
      actions.forEach(action => {
        columns[action.columnIndex].render = action.render;
      });

    return (
      <Table
        dataSource={data}
        columns={columns}
        onChange={this.handleTableChange}
        pagination={pagination}
      />
    );
  }

  handleTableChange = (pagination, filters, sorter) => {
    const { onChange } = this.props;
    if (onChange) onChange(pagination);
  };
}
