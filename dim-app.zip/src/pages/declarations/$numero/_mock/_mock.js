import mockjs from 'mockjs';

const declaration = {
  categorie: 60,
  codeIntermediaire: '1234',
  codeUtilisateur: 'ABCDE',
  dateConsultation: '10/06/2019',
  dateReception: '12/06/2019',
  dateTraitement: '13/06/2019',
  decompte: 0,
  frais: 0,
  id: 0,
  malade: 'string',
  nature: 'string',
  nomAdherent: 'string',
  nomClient: 'string',
  numeroAdherent: 0,
  numeroBeneficiaire: 0,
  numeroBordereau: 0,
  numeroCheque: 0,
  numeroClient: 0,
  numeroContrat: 0,
  observation: 'string',
  pathologie: 'string',
  rib: 'string',
  statut: 'string',
  type: 'string',
};

const prestations = mockjs.mock({
  'content|20': [
    {
      'baseRembourssement|1000-200': 0,
      'decompte|1-10': 0,
      'fraisEngage|5000-10000': 0,
      'id|1-100': 0,
      'montantDejaRembourse|1000-20000': 0,
      'montantNonRembourse|100-500': 0,
      nomPrestation: 'prestation',
      'nombreD|1-10': 0,
      'numeroDeclaration|10-30': 0,
      'plafond|1000-5000': 0,
      tauxRembourssement: '70%',
    },
  ],
});

const correspondances = mockjs.mock({
  'content|5': [
    {
      dateCorrespondance: '10/07/2019',
      datePvMedecin: '06/07/2019',
      'id|1-5': 0,
      medecin: 'dr. john doe',
      motif: 'ras',
      'numeroDeclaration|5-10': 0,
      typeCorrespondance: 'normal',
    },
  ],
});

export default {
  'GET /mock/declarationMaladies/123': declaration,
  'GET /mock/declarationMaladies/123/prestations': prestations,
  'GET /mock/declarationMaladies/123/correspondances': correspondances,
};
