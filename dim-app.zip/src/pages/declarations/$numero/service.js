import request from '@/utils/request';

export function fetchDeclaration(numeroDeclaration, paginationQuery) {
  return request(`/declarationMaladies/${numeroDeclaration}${paginationQuery}`);
}
export function fetchPrestations(numeroDeclaration, paginationQuery) {
  return request(`/declarationMaladies/${numeroDeclaration}/prestations${paginationQuery}`);
}

export function fetchCorrespondances(numeroDeclaration, paginationQuery) {
  return request(`/declarationMaladies/${numeroDeclaration}/correspondances${paginationQuery}`);
}
