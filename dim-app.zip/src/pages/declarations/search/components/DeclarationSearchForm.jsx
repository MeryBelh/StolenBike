import React, { Component } from 'react';
import { DatePicker, Input, Select } from 'antd';
import SearchBox from '../../../../components/custom/common/SearchBox';

class DeclarationSearchForm extends Component {
  hintMessage = {
    message: 'Pour rechercher une déclaration veuilez saisir soit :',
    options: [
      'Catégorie, Numéro Contrat, Date cachet  ',
      'Catégorie, Num Contrat , N° Assuré',
      'Catégorie, Num Contrat , Matricule',
      'Num declaration',
      'N° bordereau',
      'N° chéque',
    ],
  };

  handleSearch = values => {
    const { onSearch } = this.props;
    if (values.dateConsultation)
      values.dateConsultation = values.dateConsultation.format('DD/MM/YYYY');
    if (values.dateReception) values.dateReception = values.dateReception.format('DD/MM/YYYY');
    onSearch(values);
  };

  render() {
    const declarationStatuts = [
      '',
      'REGLEE',
      'CHIFREE',
      'NON TRAITEE',
      'C. Information Med tr',
      'Accord',
      'Rejet',
      'C. Information Client',
      'Contre Visite',
    ];

    return (
      <SearchBox layout="horizontal" hintMessage={this.hintMessage} onSearch={this.handleSearch}>
        <Input label="N° Déclaration" name="id" />
        <Input label="N° Assuré" name="numeroAdherent" />
        <Input label="Matricule" name="matricule" />
        <Input label="Catégorie" name="categorie" />
        <Input label="N° Contrat" name="numeroContrat" />

        <DatePicker format="DD/MM/YYYY" label="Date Cachet" name="dateReception"  />
        <DatePicker format="DD/MM/YYYY" label="Date sinistre" name="dateConsultation" />
        <Input label="N° Chéque" name="numeroCheque" secondary />
        <Select defaultValue="" label="Statut Déclaration" name="statut" secondary>
          {declarationStatuts.map(statut => (
            <Select.Option value={statut}>{statut}</Select.Option>
          ))}
        </Select>
        <Input label="N° Bordereau" name="numeroBordereau" secondary />


      </SearchBox>
    );
  }
}

export default DeclarationSearchForm;
