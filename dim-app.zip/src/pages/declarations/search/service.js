import request from '@/utils/request';

export function search(queryCommand) {
  return request('/declarationMaladies', {
    method: 'POST',
    body: JSON.stringify(queryCommand),
    headers: { 'content-type': 'Application/json' },
  });
}
