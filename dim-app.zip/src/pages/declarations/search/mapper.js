import { Link } from 'react-router-dom';
import { applyPolicy } from '../../../utils/utils';

const declarationMapper = applyPolicy([
  {
    label: 'N° déclaration',
    name: 'id',
    render: numero => {
      return <Link to={`/sinistre/declarations/${numero}`}>{numero} </Link>;
    },
  },
  { label: 'N° Assuré', name: 'numeroAdherent' },
  { label: 'Assuré', name: 'nomAdherent' },
  { label: 'Malade', name: 'malade' },
  { label: 'Nature', name: 'nature' },
  { label: 'Type', name: 'type' },
  { label: 'DT. sinistre', name: 'dateConsultation' },
  { label: 'Frais', name: 'frais' },
  { label: 'Décompte', name: 'decompte' },
  { label: 'Statut', name: 'statut' },
]);

export default declarationMapper;
