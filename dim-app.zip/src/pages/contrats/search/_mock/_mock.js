export default {
  'POST /mock/contrats/': {
    content: [
      {
        adresse: 'une adresse',
        categorie: 60,
        codeIntermediaire: '9000',
        dateDebut: '24/10/2016',
        nomCategorie: 'Une categorie',
        nomClient: 'Chi client',
        nomIntermediaire: "L'intermediaire",
        numeroClient: '390903',
        numeroContrat: 363400,
      },
    ],
  },
};
