import React from 'react';
import { Col, Row } from 'antd';
import SearchContratsForm from './SearchContratsForm';
import { Link } from 'react-router-dom';
import DataTable from '@/components/custom/common/DataTable';

class SearchContratsPage extends React.Component {
  searchValues = {};

  model = 'contratSearch';

  search = values => {
    this.searchValues = values;
    this.fetchSearch();
  };

  fetchSearch = (pagination = {}) => {
    const { dispatch } = this.props;
    dispatch({
      type: `${this.model}/searchContrat`,
      payload: { values: this.searchValues, frontPagination: pagination },
    });
  };

  render() {
    const { contrats } = this.props;

    const actions = [
      {
        columnIndex: 0,
        render: (numeroContrat, obj) => {
          const numero = `${obj.categorie},${obj.numeroContrat}`;
          return <Link to={`/production/contrats/${numero}`}> {numero.replace(',', '/')} </Link>;
        },
      },
    ];

    return (
      <>
        <Row>
          <Col>
            <SearchContratsForm onSearch={this.search} />
          </Col>
        </Row>
        <Row>
          <Col>
            <DataTable dataSource={contrats} actions={actions} onChange={this.fetchSearch} />
          </Col>
        </Row>
      </>
    );
  }
}

export default SearchContratsPage;
