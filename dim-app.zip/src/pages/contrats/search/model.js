import { search } from './service';
import { contratMapper } from './mapper';
import DataSource from '../../../utils/DataSource';

export default {
  namespace: 'contratSearch',
  state: {
    contrats: new DataSource(contratMapper),
  },
  effects: {
    *searchContrat({ payload }, { call, put }) {
      try {
        const { frontPagination, values } = payload;
        const contrats = new DataSource(contratMapper, frontPagination);
        contrats.setData = yield call(search, { ...values, ...contrats.getBackendPagination() });
        yield put({
          type: 'contratsFetched',
          payload: contrats,
        });
      } catch (e) {
        console.log(e);
      }
    },
  },

  reducers: {
    contratsFetched(state, action) {
      return {
        ...state,
        contrats: action.payload,
      };
    },
  },
};
