import { Link } from 'react-router-dom';
import React from 'react';
import { applyPolicy } from '../../../utils/utils';

const contratMapper = applyPolicy([
  {
    label: 'Numero Contrat',
    name: 'numeroContrat',
    key: 'numeroContrat',
    render: (numeroContrat, obj) => {
      const numero = `${obj.categorie},${numeroContrat}`;
      return (
        <Link to={'/production/contrats/' + numero}>{obj.categorie + '/' + numeroContrat} </Link>
      );
    },
  },
  { label: 'Produit', name: 'nomCategorie', key: 'nomCategorie' },
  { label: 'Catégorie', name: 'categorie', key: 'categorie' },
  { label: 'Police', name: 'numeroContrat', key: 'numeroContrat' },
  { label: 'Effet', name: 'dateDebut', key: 'dateDebut' },
  { label: 'Soucripteur', name: 'nomClient', key: 'nomClient' },
  { label: 'Adresse', name: 'adresse', key: 'adresse' },
]);

const contratSearchMapper = applyPolicy([
  { label: 'Catégorie', name: 'categorie', required: true },
  { label: 'Num Contrat', name: 'numeroContrat' },
  { label: 'Nom Client', name: 'nomClient' },
]);

export { contratMapper, contratSearchMapper };
