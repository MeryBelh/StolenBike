import request from '@/utils/request';

export function search(queryCommand) {
  return request('/contrats', {
    method: 'POST',
    body: JSON.stringify(queryCommand),
    headers: { 'content-type': 'Application/json' },
  });
}
