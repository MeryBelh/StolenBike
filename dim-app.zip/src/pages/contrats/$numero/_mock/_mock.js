import mockjs from 'mockjs';

let { avenants } = mockjs.mock({
  'avenants|100': [
    {
      ageLimite: 65,
      ageLimiteEnfant: 12,
      ageRetraite: 65,
      categorie: 60,
      dateDebut: '03/07/2019',
      numeroContrat: 363400,
      'plafond|1-100': 0,
      rachatAnteriorite: 'rachat Anteriorite',
      typePlafond: 'Plafond 1',
    },
  ],
});

let prestations = mockjs.mock({
  'content|100': [
    {
      categorie: 60,
      'code|1-100': 0,
      dateDebut: '03/07/2019',
      intitule: 'Intitule',
      numeroContrat: 363400,
      'plafond|100-500': 0,
      taux: '30%',
      'valeurD|1000-10000': 1000,
    },
  ],
});

let clauses = mockjs.mock({
  'content|100': [
    {
      categorie: 60,
      'code|10-20': 0,
      libelle: 'libelle',
      numeroContrat: 363400,
      dateEffet: '16/07/2019',
    },
  ],
});

let primes = mockjs.mock({
  'content|50': [
    {
      categorie: 60,
      codeIntermediaire: 'codeIntermediaire',
      dateDebut: '01/01/2000',
      dateEmission: '01/01/2001',
      dateFin: '01/01/2020',
      exercice: 2019,
      nomClient: 'cosumar',
      numeroClient: 'client1',
      numeroContrat: 363400,
      'numeroPrime|1-100': 0,
      'primeNette|1000-10000': 0,
      'primeTtc|1000-10000': 0,
      statut: 'payé',
      trimestre: 2,
    },
  ],
});

export default {
  'GET /mock/contrats/60,363400/avenants': avenants,
  'GET /mock/contrats/60,363400/prestations': prestations,
  'GET /mock/contrats/60,363400/clauses': clauses,
  'GET /mock/contrats/60,363400/primes': primes,
};
