import request from '@/utils/request';

export function fetchAvenants(numeroContrat) {
  return request(`/contrats/${numeroContrat}/avenants`);
}
export function fetchPrestations(numeroContrat, queryString) {
  return request(`/contrats/${numeroContrat}/prestations${queryString}`);
}
export function fetchClauses(numeroContrat, queryString) {
  return request(`/contrats/${numeroContrat}/clauses-particulieres${queryString}`);
}
export function fetchPrimes(numeroContrat, queryString) {
  return request(`/contrats/${numeroContrat}/primes${queryString}`);
}
