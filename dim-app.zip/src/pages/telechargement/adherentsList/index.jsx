import React, { Component } from 'react';
import { Input } from 'antd';
import SearchBox from '../../../components/custom/common/SearchBox';

class AdherentsList extends Component {
  hintMessage = {
    message: 'Pour rechercher la liste des adhérents veuilez saisir',
    options: ['Catégorie, Num Contrat'],
  };

  handleSearch = values => {
    console.log(values);
  };

  render() {
    return (
      <div>
        <h1>liste des adhérents</h1>
        <SearchBox layout="horizontal" onSearch={this.handleSearch} hintMessage={this.hintMessage}>
          <Input label="Catégorie" name="categorie" required="true" />
          <Input label="N° Contrat" name="numContrat" required="true" />
        </SearchBox>
      </div>
    );
  }
}

export default AdherentsList;
