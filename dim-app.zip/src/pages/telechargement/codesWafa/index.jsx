import React, { Component } from 'react';
import { Input } from 'antd';
import SearchBox from '../../../components/custom/common/SearchBox';

class CodesWafa extends Component {
  hintMessage = {
    message: 'Pour rechercher les codes wafa santé veuilez saisir',
    options: ['Catégorie, Num Contrat'],
  };
  handleSearch = values => {
    console.log(values);
  };
  render() {
    return (
      <div>
        <h1>Code Wafa Santé</h1>
        <SearchBox layout="horizontal" onSearch={this.handleSearch} hintMessage={this.hintMessage}>
          <Input label="Catégorie" name="categorie" required="true" />
          <Input label="N° Contrat" name="numContrat" required="true" />
        </SearchBox>
      </div>
    );
  }
}

export default CodesWafa;
