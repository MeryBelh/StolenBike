import React, { Component } from 'react';
import { Input } from 'antd';
import SearchBox from '../../../components/custom/common/SearchBox';

class DecomptesSearch extends Component {
  hintMessage = {
    message: 'Pour rechercher les décomptes veuilez saisir',
    options: ['Catégorie, Num Contrat, date Décompte'],
  };
  handleSearch = values => {
    console.log(values);
  };
  render() {
    return (
      <SearchBox layout="horizontal" onSearch={this.handleSearch} hintMessage={this.hintMessage}>
        <Input label="Catégorie" name="categorie" required="true" />
        <Input label="N° Contrat" name="numContrat" required="true" />
        <Input label="Date Décompte" name="dateDecompte" required="true" />
      </SearchBox>
    );
  }
}

export default DecomptesSearch;
