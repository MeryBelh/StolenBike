import React, { Component } from 'react';
import { DatePicker, Input, Select } from 'antd';
import SearchBox from '../../../../components/custom/common/SearchBox';

class ReclamationSearchForm extends Component {
  hintMessage = {
    message: 'Pour rechercher une prime veuilez saisir soit :',
    options: [
      'Numéro Reclamation',
      'Catégorie, Numéro Contrat',
      'Numéro Déclaraion',
      'Date Saisie',
      'Catégorie, Numéro Contrat, Statut',
    ],
  };

  handleSearch = values => {
    const { onSearch } = this.props;
    if (values.dateSaisie) values.dateSaisie = values.dateSaisie.format('DD/MM/YYYY');
    onSearch(values);
  };

  render() {
    return (
      <SearchBox hintMessage={this.hintMessage} onSearch={this.handleSearch}>
        <Input label="Numéro Réclamation" name="numeroReclamation" />

        <DatePicker format="DD/MM/YYYY" label="Date Saisie" name="dateSaisie" />

        <Input name="numeroDeclaraion" label="Numéro Déclaration" />

        <Input name="categorie" label="Catégorie" />

        <Input name="numeroContrat" label="Numéro Contrat" />

        <Select defaultValue="" label="statut" name="statut">
          {['', 'TRAITEE', 'NON TRAITEE'].map(statut => (
            <Select.Option value={statut}>{statut}</Select.Option>
          ))}
        </Select>
      </SearchBox>
    );
  }
}

export default ReclamationSearchForm;
