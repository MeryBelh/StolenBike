import request from '@/utils/request';

export function search(queryCommand) {
  return request('/reclamations', {
    method: 'POST',
    body: JSON.stringify(queryCommand),
    headers: { 'Content-Type': 'Application/json' },
  });
}
