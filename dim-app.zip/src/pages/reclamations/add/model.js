import { saveReclamation } from './service';

export default {
  namespace: 'reclamations',
  state: {},
  effects: {
    *saveReclamation({ payload }, { call }) {
      console.log('%c saveReclamation ', 'color: blue;');
      yield call(saveReclamation, payload);
    },
  },
};
