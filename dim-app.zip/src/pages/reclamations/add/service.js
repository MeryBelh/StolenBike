import request from '@/utils/request';

export function saveReclamation(reclamation) {
  return request(`/declarationMaladies/${reclamation.numeroDeclaraion}/reclamer`, {
    method: 'POST',
    body: JSON.stringify(reclamation),
    headers: { 'Content-Type': 'Application/json' },
  });
}
