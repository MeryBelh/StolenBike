import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@tmp/history';
import RendererWrapper0 from 'C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/pages/.umi/LocaleWrapper.jsx';
import _dvaDynamic from 'dva/dynamic';

const Router = require('dva/router').routerRedux.ConnectedRouter;

const routes = [
  {
    name: 'login',
    path: '/user/login',
    icon: 'smile',
    component: __IS_BROWSER
      ? _dvaDynamic({
          app: require('@tmp/dva').getApp(),
          models: () => [
            import(/* webpackChunkName: 'p__user__login__model.ts' */ 'C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/pages/user/login/model.ts').then(
              m => {
                return { namespace: 'model', ...m.default };
              },
            ),
          ],
          component: () =>
            import(/* webpackChunkName: "p__user__login__index" */ '../user/login/index'),
          LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
            .default,
        })
      : require('../user/login/index').default,
    Routes: [require('../Authorized').default],
    exact: true,
  },
  {
    path: '/',
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () =>
            import(/* webpackChunkName: "layouts__BasicLayout" */ '../../layouts/BasicLayout'),
          LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
            .default,
        })
      : require('../../layouts/BasicLayout').default,
    Routes: [require('../Authorized').default],
    routes: [
      {
        path: '/',
        name: 'Acceuil',
        icon: 'home',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__accueil__Welcome" */ '../accueil/Welcome'),
              LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
                .default,
            })
          : require('../accueil/Welcome').default,
        authority: ['ROLE_CLIENT', 'user'],
        exact: true,
      },
      {
        name: 'Production',
        path: '/production',
        icon: 'smile',
        Routes: [require('../Authorized').default],
        routes: [
          {
            name: 'Contrat',
            path: '/production/contrats',
            icon: 'smile',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  app: require('@tmp/dva').getApp(),
                  models: () => [
                    import(/* webpackChunkName: 'p__contrats__search__model.js' */ 'C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/pages/contrats/search/model.js').then(
                      m => {
                        return { namespace: 'model', ...m.default };
                      },
                    ),
                  ],
                  component: () =>
                    import(/* webpackChunkName: "p__contrats__search__index" */ '../contrats/search/index'),
                  LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
                    .default,
                })
              : require('../contrats/search/index').default,
            Routes: [require('../Authorized').default],
            authority: ['ROLE_CLIENT', 'user'],
            exact: true,
          },
          {
            path: '/production/contrats/:numero',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  app: require('@tmp/dva').getApp(),
                  models: () => [
                    import(/* webpackChunkName: 'p__contrats__$numero__model.js' */ 'C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/pages/contrats/$numero/model.js').then(
                      m => {
                        return { namespace: 'model', ...m.default };
                      },
                    ),
                  ],
                  component: () =>
                    import(/* webpackChunkName: "p__contrats__$numero__index" */ '../contrats/$numero/index'),
                  LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
                    .default,
                })
              : require('../contrats/$numero/index').default,
            Routes: [require('../Authorized').default],
            authority: ['ROLE_CLIENT', 'user'],
            exact: true,
          },
          {
            name: 'Assuré',
            path: '/production/adherents',
            icon: 'smile',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  app: require('@tmp/dva').getApp(),
                  models: () => [
                    import(/* webpackChunkName: 'p__adherents__search__model.js' */ 'C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/pages/adherents/search/model.js').then(
                      m => {
                        return { namespace: 'model', ...m.default };
                      },
                    ),
                  ],
                  component: () =>
                    import(/* webpackChunkName: "p__adherents__search__index" */ '../adherents/search/index'),
                  LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
                    .default,
                })
              : require('../adherents/search/index').default,
            Routes: [require('../Authorized').default],
            authority: ['ROLE_CLIENT', 'user'],
            exact: true,
          },
          {
            path: '/production/adherents/:numero',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  app: require('@tmp/dva').getApp(),
                  models: () => [
                    import(/* webpackChunkName: 'p__adherents__$numero__model.js' */ 'C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/pages/adherents/$numero/model.js').then(
                      m => {
                        return { namespace: 'model', ...m.default };
                      },
                    ),
                  ],
                  component: () =>
                    import(/* webpackChunkName: "p__adherents__$numero__index" */ '../adherents/$numero/index'),
                  LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
                    .default,
                })
              : require('../adherents/$numero/index').default,
            Routes: [require('../Authorized').default],
            authority: ['ROLE_CLIENT', 'user'],
            exact: true,
          },
          {
            name: 'Primes',
            path: '/production/prime',
            icon: 'smile',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  app: require('@tmp/dva').getApp(),
                  models: () => [
                    import(/* webpackChunkName: 'p__primes__search__model.js' */ 'C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/pages/primes/search/model.js').then(
                      m => {
                        return { namespace: 'model', ...m.default };
                      },
                    ),
                  ],
                  component: () =>
                    import(/* webpackChunkName: "p__primes__search__index" */ '../primes/search/index'),
                  LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
                    .default,
                })
              : require('../primes/search/index').default,
            Routes: [require('../Authorized').default],
            authority: ['ROLE_CLIENT', 'user'],
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        name: 'PEC',
        path: '/pec',
        icon: 'smile',
        Routes: [require('../Authorized').default],
        routes: [
          {
            name: 'Laboratoire',
            path: '/pec/laboratoire',
            icon: 'smile',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  app: require('@tmp/dva').getApp(),
                  models: () => [
                    import(/* webpackChunkName: 'p__prise-charge__laboratoire__model.js' */ 'C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/pages/prise-charge/laboratoire/model.js').then(
                      m => {
                        return { namespace: 'model', ...m.default };
                      },
                    ),
                  ],
                  component: () =>
                    import(/* webpackChunkName: "p__prise-charge__laboratoire__index" */ '../prise-charge/laboratoire/index'),
                  LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
                    .default,
                })
              : require('../prise-charge/laboratoire/index').default,
            Routes: [require('../Authorized').default],
            authority: ['ROLE_CLIENT', 'user'],
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        name: 'Sinistre',
        path: '/sinistre',
        icon: 'smile',
        Routes: [require('../Authorized').default],
        authority: ['ROLE_CLIENT', 'user'],
        routes: [
          {
            path: '/sinistre/bordereaux/:numero',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  app: require('@tmp/dva').getApp(),
                  models: () => [
                    import(/* webpackChunkName: 'p__bordereaux__$numero__model.js' */ 'C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/pages/bordereaux/$numero/model.js').then(
                      m => {
                        return { namespace: 'model', ...m.default };
                      },
                    ),
                  ],
                  component: () =>
                    import(/* webpackChunkName: "p__bordereaux__$numero__index" */ '../bordereaux/$numero/index'),
                  LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
                    .default,
                })
              : require('../bordereaux/$numero/index').default,
            Routes: [require('../Authorized').default],
            authority: ['ROLE_CLIENT', 'user'],
            exact: true,
          },
          {
            name: 'Déclaration',
            path: '/sinistre/declarations',
            icon: 'smile',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  app: require('@tmp/dva').getApp(),
                  models: () => [
                    import(/* webpackChunkName: 'p__declarations__search__model.js' */ 'C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/pages/declarations/search/model.js').then(
                      m => {
                        return { namespace: 'model', ...m.default };
                      },
                    ),
                  ],
                  component: () =>
                    import(/* webpackChunkName: "p__declarations__search__index" */ '../declarations/search/index'),
                  LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
                    .default,
                })
              : require('../declarations/search/index').default,
            Routes: [require('../Authorized').default],
            authority: ['ROLE_CLIENT', 'user'],
            exact: true,
          },
          {
            path: '/sinistre/declarations/:numero',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  app: require('@tmp/dva').getApp(),
                  models: () => [
                    import(/* webpackChunkName: 'p__declarations__$numero__model.js' */ 'C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/pages/declarations/$numero/model.js').then(
                      m => {
                        return { namespace: 'model', ...m.default };
                      },
                    ),
                  ],
                  component: () =>
                    import(/* webpackChunkName: "p__declarations__$numero__index" */ '../declarations/$numero/index'),
                  LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
                    .default,
                })
              : require('../declarations/$numero/index').default,
            Routes: [require('../Authorized').default],
            authority: ['ROLE_CLIENT', 'user'],
            exact: true,
          },
          {
            name: 'Réglements Bloqués',
            path: '/sinistre/reglements-bloques',
            icon: 'smile',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  app: require('@tmp/dva').getApp(),
                  models: () => [
                    import(/* webpackChunkName: 'p__reglements-bloques__search__model.js' */ 'C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/pages/reglements-bloques/search/model.js').then(
                      m => {
                        return { namespace: 'model', ...m.default };
                      },
                    ),
                  ],
                  component: () =>
                    import(/* webpackChunkName: "p__reglements-bloques__search__index" */ '../reglements-bloques/search/index'),
                  LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
                    .default,
                })
              : require('../reglements-bloques/search/index').default,
            Routes: [require('../Authorized').default],
            authority: ['ROLE_CLIENT', 'user'],
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        name: 'Réclamations',
        path: '/reclamations',
        icon: 'exclamation',
        Routes: [require('../Authorized').default],
        routes: [
          {
            name: 'List des Réclamations ',
            path: '/reclamations/list',
            icon: 'exclamation',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  app: require('@tmp/dva').getApp(),
                  models: () => [
                    import(/* webpackChunkName: 'p__reclamations__search__model.js' */ 'C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/pages/reclamations/search/model.js').then(
                      m => {
                        return { namespace: 'model', ...m.default };
                      },
                    ),
                  ],
                  component: () =>
                    import(/* webpackChunkName: "p__reclamations__search__index" */ '../reclamations/search/index'),
                  LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
                    .default,
                })
              : require('../reclamations/search/index').default,
            Routes: [require('../Authorized').default],
            authority: ['ROLE_CLIENT', 'user'],
            exact: true,
          },
          {
            name: 'Réclamer',
            path: '/reclamations/reclamer',
            icon: 'exclamation',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  app: require('@tmp/dva').getApp(),
                  models: () => [
                    import(/* webpackChunkName: 'p__reclamations__add__model.js' */ 'C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/pages/reclamations/add/model.js').then(
                      m => {
                        return { namespace: 'model', ...m.default };
                      },
                    ),
                  ],
                  component: () =>
                    import(/* webpackChunkName: "p__reclamations__add__index" */ '../reclamations/add/index'),
                  LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
                    .default,
                })
              : require('../reclamations/add/index').default,
            Routes: [require('../Authorized').default],
            authority: ['ROLE_CLIENT', 'user'],
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        name: 'Téléchargement',
        path: '/telechargement',
        icon: 'arrow-down',
        Routes: [require('../Authorized').default],
        routes: [
          {
            name: 'Codes Wafa Santé',
            path: '/telechargement/codesWafa',
            icon: 'smile',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__telechargement__codesWafa__index" */ '../telechargement/codesWafa/index'),
                  LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
                    .default,
                })
              : require('../telechargement/codesWafa/index').default,
            Routes: [require('../Authorized').default],
            authority: ['ROLE_CLIENT', 'user'],
            exact: true,
          },
          {
            name: 'Liste des assurés',
            path: '/telechargement/adherentsList',
            icon: 'smile',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__telechargement__adherentsList__index" */ '../telechargement/adherentsList/index'),
                  LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
                    .default,
                })
              : require('../telechargement/adherentsList/index').default,
            Routes: [require('../Authorized').default],
            authority: ['ROLE_CLIENT', 'user'],
            exact: true,
          },
          {
            name: 'Edition des décomptes',
            path: '/telechargement/decomptes',
            icon: 'smile',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__telechargement__decomptes__index" */ '../telechargement/decomptes/index'),
                  LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
                    .default,
                })
              : require('../telechargement/decomptes/index').default,
            Routes: [require('../Authorized').default],
            authority: ['ROLE_CLIENT', 'user'],
            exact: true,
          },
          {
            name: 'Médicaments',
            path: '/telechargement/medicaments',
            icon: 'medicine-box',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__telechargement__medicaments__index" */ '../telechargement/medicaments/index'),
                  LoadingComponent: require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/src/components/PageLoading/index')
                    .default,
                })
              : require('../telechargement/medicaments/index').default,
            Routes: [require('../Authorized').default],
            authority: ['ROLE_CLIENT', 'user'],
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        component: () =>
          React.createElement(
            require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
      },
    ],
  },
  {
    component: () =>
      React.createElement(
        require('C:/Users/reda.adari/Documents/wafaassurance/dim-app/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
          .default,
        { pagesPath: 'src/pages', hasRoutesInConfig: true },
      ),
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen = () => {};

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    routeChangeHandler(history.location);
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return (
      <RendererWrapper0>
        <Router history={history}>{renderRoutes(routes, props)}</Router>
      </RendererWrapper0>
    );
  }
}
