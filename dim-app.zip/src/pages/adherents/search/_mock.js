import mockjs from 'mockjs';

const adherents = mockjs.mock({
  'content|100': [
    {
      'categorie|1-5': 0,
      cleActivation: 'cleActivation',
      codeIntermediaire: 'codeIntermediaire',
      dateAdhesion: '01/01/1970',
      dateEmbauche: '01/01/1970',
      dateNaissance: '01/01/1970',
      nomAdherent: 'john doe',
      numeroAdherent: 1234,
      'numeroContrat|1-5': 0,
      'numeroMatricule|1-100': 0,
      regime: 'regime',
      rib: '123456789XXXXX',
      ribInstance: '123456789XXXXX',
      sexe: 'male',
      situationFamiliale: 'célibataire',
      statut: 'Employe',
      etatAdherent: 'Garantie Radié',
    },
  ],
});

export default {
  'POST /mock/adherents': adherents,
};
