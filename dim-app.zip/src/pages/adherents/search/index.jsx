import React from 'react';
import { connect } from 'dva';

import AdherentSearchPage from './Components/AdherentSearchPage';
const mapStateToProps = ({ adherentSearch }) => ({
  adherents: adherentSearch.adherents,
});

export default connect(mapStateToProps)(AdherentSearchPage);
