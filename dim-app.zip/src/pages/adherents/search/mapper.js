import { Link } from 'react-router-dom';
import React from 'react';
import { applyPolicy } from '../../../utils/utils';

const adherentMapper = applyPolicy([
  {
    label: 'N° Assuré',
    name: 'numeroAdherent',
    render: numeroAdherent => {
      return <Link to={`/production/adherents/${numeroAdherent}`}>{numeroAdherent} </Link>;
    },
  },
  { label: 'Matricule', name: 'numeroMatricule' },
  { label: 'Nom/prénom', name: 'nomAdherent' },
  { label: 'Date Adhésion', name: 'dateAdhesion', type: 'date' },
  { label: 'Date Naissance', name: 'dateNaissance', type: 'date' },
  { label: 'Etat', name: 'etatAdherent' },
  { label: 'Code Wafa Santé', name: 'cleActivation', deniedFor: ['ROLE_PRESTATAIRE'] },
]);

const adherentSearchMapper = applyPolicy([
  { label: 'Catégorie', name: 'categorie' },
  { label: 'N° Contrat', name: 'numeroContrat' },
  { label: 'N° Assuré', name: 'numeroAdherent' },
  { label: 'Matricule', name: 'matricule' },
  { label: 'Nom Assuré', name: 'nomAdherent', deniedFor: ['ROLE_PRESTATAIRE'] },
]);

export { adherentMapper, adherentSearchMapper };
