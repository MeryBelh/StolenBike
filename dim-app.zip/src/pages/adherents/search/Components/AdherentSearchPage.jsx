import React, { Component } from 'react';
import { Col, Row } from 'antd';
import DataTable from '@/components/custom/common/DataTable';
import AdherentSearchForm from './AdherentSearchForm';

class AdherentSearchPage extends Component {
  model = 'adherentSearch';

  searchValues = {};

  handleSearch = values => {
    this.searchValues = values;
    this.fetchSearch();
  };

  fetchSearch = (pagination = {}) => {
    const { dispatch } = this.props;

    dispatch({
      type: `${this.model}/search`,
      payload: { values: this.searchValues, frontPagination: pagination },
    });
  };

  render() {
    const { adherents } = this.props;

    return (
      <>
        <Row>
          <Col>
            <AdherentSearchForm onSearch={this.handleSearch} />
          </Col>
        </Row>
        <Row>
          <Col>
            <DataTable dataSource={adherents} onChange={this.fetchSearch} />
          </Col>
        </Row>
      </>
    );
  }
}

export default AdherentSearchPage;
