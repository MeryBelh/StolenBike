import { search } from './service';
import DataSource from '../../../utils/DataSource';
import { adherentMapper } from './mapper';

export default {
  namespace: 'adherentSearch',
  state: {
    adherents: new DataSource(adherentMapper),
  },
  effects: {
    *search({ payload }, { call, put }) {
      try {
        const { frontPagination, values } = payload;
        const adherents = new DataSource(adherentMapper, frontPagination);
        adherents.setData = yield call(search, { ...values, ...adherents.getBackendPagination() });

        yield put({
          type: 'adherentsFetched',
          payload: adherents,
        });
      } catch (e) {
        console.log(e);
      }
    },
  },

  reducers: {
    adherentsFetched(state, action) {
      return {
        ...state,
        adherents: action.payload,
      };
    },
  },
};
