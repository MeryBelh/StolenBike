import request from '@/utils/request';

export function fetchBeneficiaires(numeroAdherent, paginationquery) {
  return request(`/adherents/${numeroAdherent}/beneficiaires${paginationquery}`);
}
export function fetchAdherentHistoriques(numeroAdherent, paginationquery) {
  return request(`/adherents/${numeroAdherent}/historiques${paginationquery}`);
}
export function fetchAdherent(numeroAdherent) {
  return request('/adherents', {
    method: 'POST',
    body: JSON.stringify({ numeroAdherent }),
    headers: { 'Content-Type': 'Application/json' },
  });
}
