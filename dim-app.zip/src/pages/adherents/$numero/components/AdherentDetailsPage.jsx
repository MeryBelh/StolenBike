import React, { Component } from 'react';
import { Tabs } from 'antd';
import DataTable from '../../../../components/custom/common/DataTable';
import AdherentDetailsDescription from './AdherentDetailsDescription';
import { getAuthority } from '../../../../utils/authority';
const { TabPane } = Tabs;

class AdherentDetailsPage extends Component {
  model = 'adherentDetails';

  componentDidMount() {
    this.fetchData('fetchBeneficiaires');
    this.fetchData('fetchAdherentHistoriques');
    this.fetchData('fetchAdherent');
  }

  fetchData = (action, frontPagination = {}) => {
    const {
      dispatch,
      match: {
        params: { numero },
      },
    } = this.props;
    dispatch({ type: 'adherentDetails/fetchBeneficiaires', payload: { numero, frontPagination } });
    dispatch({
      type: 'adherentDetails/fetchAdherentHistoriques',
      payload: { numero, frontPagination },
    });
    dispatch({ type: 'adherentDetails/fetchAdherent', payload: { numero, frontPagination } });
  };

  render() {
    const {
      beneficiaires,
      adherentHistoriques,
      adherent,
      match: {
        params: { numero },
      },
    } = this.props;

    const adherentDetails = adherent ? (adherent.content ? adherent.content[0] : {}) : {};
    return (
      <div>
        <h1>
          {' '}
          {adherentDetails.nomAdherent} N° : {numero}{' '}
        </h1>
        <Tabs defaultActiveKey="1">
          <Tabs.TabPane tab="Assuré Details" key="1">
            <AdherentDetailsDescription adherent={adherentDetails} />
          </Tabs.TabPane>

          {getAuthority().includes('ROLE_PRESTATAIRE') ? null : (
            <TabPane tab="Beneficiaires" key="2">
              <DataTable
                dataSource={beneficiaires}
                onChange={pagination => this.fetchData('fetchBeneficiaires', pagination)}
              />
            </TabPane>
          )}
          {getAuthority().includes('ROLE_PRESTATAIRE') ? null : (
            <TabPane tab="Assuré Historiques" key="3">
              <DataTable
                dataSource={adherentHistoriques}
                onChange={pagination => this.fetchData('fetchAdherentHistoriques', pagination)}
              />
            </TabPane>
          )}
        </Tabs>
      </div>
    );
  }
}

export default AdherentDetailsPage;
