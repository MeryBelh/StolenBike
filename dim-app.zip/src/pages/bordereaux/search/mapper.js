import { Link } from 'react-router-dom';
import React from 'react';
import { applyPolicy } from '../../../utils/utils';

const bordereauMapper = applyPolicy([
  {
    label: 'Identifiant',
    name: 'id',
    render: numeroBordereau => {
      return <Link to={`/sinistre/bordereaux/${numeroBordereau}`}> {numeroBordereau} </Link>;
    },
  },
  { label: 'Réf. intérmidiaire', name: 'referenceExterne', key: 'referenceExterne' },
  { label: 'Date cachet', name: 'datecachet', key: 'datecachet' },
  { label: 'Catégorie', name: 'categorie', key: 'categorie' },
  { label: 'Police', name: 'numeroContrat', key: 'numeroContrat' },
  { label: 'Souscripteur', name: 'nomClient', key: 'nomClient' },
  { label: 'Statut', name: 'statut', key: 'statut' },
  { label: 'Nombre', name: 'nombreDeclarationMaladie', key: 'nombreDeclarationMaladie' },
  {
    label: 'Nb en instance',
    name: 'nombreDeclarationMaladieEnInstance',
    key: 'nombreDeclarationMaladieEnInstance',
  },
]);

export default bordereauMapper;
