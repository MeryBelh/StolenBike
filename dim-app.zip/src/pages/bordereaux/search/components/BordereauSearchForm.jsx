import React, { Component } from 'react';
import { Input } from 'antd';
import SearchBox from '../../../../components/custom/common/SearchBox';

class BordereauSearchForm extends Component {
  hintMessage = {
    message: 'Pour rechercher un bordereau veuilez saisir soit :',
    options: ['Identifiant', 'Catégorie, Num Contrat , Date Cahcet'],
  };

  handleSearch = values => {
    const { onSearch } = this.props;
    onSearch(values);
  };

  render() {
    return (
      <SearchBox layout="horizontal" onSearch={this.handleSearch} hintMessage={this.hintMessage}>
        <Input label="Identifiant" name="id" />
        <Input label="Réf. intermédiaire" name="referenceExterne" />
        <Input label="Catégorie" name="categorie" />
        <Input label="N° Contrat" name="numeroContrat" />
        <Input label="Date Cachet" name="dateCachet" />
      </SearchBox>
    );
  }
}

export default BordereauSearchForm;
