import mockjs from 'mockjs';

const bordereaux = mockjs.mock({
  'content|100': [
    {
      'categorie|1-10': 0,
      codeIntermediaire: 'codeIntermediaire',
      datecachet: '05/06/2019',
      'id|1-100': 0,
      nomClient: 'john doe',
      'nombreDeclarationMaladie|3-20': 0,
      'nombreDeclarationMaladieEnInstance|3-20': 0,
      'numeroClient|1-10': 0,
      'numeroContrat|1-10': 0,
      referenceExterne: 'ref',
      statut: 'progress',
    },
  ],
});

export default {
  'POST /mock/bordereaux': bordereaux,
};
