import request from '@/utils/request';

export function fetchDeclarations(numeroBordereau) {
  return request('/declarationMaladies', {
    method: 'POST',
    body: JSON.stringify({numeroBordereau}),
    headers: { 'content-type': 'Application/json' },
  });
}
