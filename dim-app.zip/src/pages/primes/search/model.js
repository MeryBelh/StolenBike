import { search } from './service';
import primeMapper from './mapper';
import DataSource from '../../../utils/DataSource';

export default {
  namespace: 'primesSearch',
  state: {
    primes: new DataSource(primeMapper),
  },
  effects: {
    *search({ payload }, { call, put }) {
      try {
        const { values, frontPagination } = payload;
        const primes = new DataSource(primeMapper, frontPagination);
        primes.setData = yield call(search, { ...values, ...primes.getBackendPagination() });
        yield put({
          type: 'primesFetched',
          payload: primes,
        });
      } catch (e) {
        console.log(e);
      }
    },
  },

  reducers: {
    primesFetched(state, action) {
      return {
        ...state,
        primes: action.payload,
      };
    },
  },
};
