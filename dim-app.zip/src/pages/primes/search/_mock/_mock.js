import mockjs from 'mockjs';

const primes = mockjs.mock({
  'content|100': [
    {
      'categorie|0-100': 0,
      codeIntermediaire: 'codeIntermediaire',
      dateDebut: '01/01/2000',
      dateEmission: '01/01/2001',
      dateFin: '01/01/2020',
      exercice: 2019,
      nomClient: 'cosumar',
      numeroClient: 'client1',
      'numeroContrat|1-100': 0,
      'numeroPrime|1-100': 0,
      'primeNette|1000-10000': 0,
      'primeTtc|1000-10000': 0,
      statut: 'payé',
      trimestre: 2,
    },
  ],
});

export default {
  'POST /mock/primes': primes,
};
