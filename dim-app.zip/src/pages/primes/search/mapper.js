import { applyPolicy } from '../../../utils/utils';

const primeMapper = applyPolicy([
  { label: 'N° prime', name: 'numeroPrime', key: 'numeroPrime' },
  { label: 'Catégorie', name: 'categorie', key: 'categorie' },
  { label: 'N° Contrat', name: 'numeroContrat', key: 'numeroContrat' },
  { label: 'Souscripteur', name: 'nomClient', key: 'nomClient' },
  { label: 'Date début', name: 'dateDebut', key: 'dateDebut' },
  { label: 'Date fin ', name: 'dateFin', key: 'dateFin' },
  { label: "Date d'émission ", name: 'dateEmission', key: 'dateEmission' },
  { label: 'Montant', name: 'primeNette', key: 'primeNette' },
  { label: 'Statut', name: 'statut', key: 'statut' },
]);

export default primeMapper;
