import React from 'react';
import { Input, Form } from 'antd';

export default () => {
  const { TextArea } = Input;
  return (
    <Form.Item label="Observations:">
      <TextArea rows={4} placeholder="Ecrire votre commentaire" />
    </Form.Item>
  );
};
