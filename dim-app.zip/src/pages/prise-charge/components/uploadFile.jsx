import React, { Component } from 'react';
import { Upload, Button, Icon } from 'antd';

export default class extends Component {
  state = {
    fileList: [],
  };

  handleChange = info => {
    let fileList = [...info.fileList];

    fileList = fileList.map(file => {
      if (file.response) {
        file.url = file.response.url;
      }
      return file;
    });

    this.setState({ fileList });
  };

  render() {
    const props = {
      action: '',
      onChange: this.handleChange,
      multiple: true,
    };
    return (
      <Upload {...props} fileList={this.state.fileList}>
        Joindre documents du soin &nbsp;&nbsp;&nbsp;&nbsp;
        <Button>
          <Icon type="upload" /> Joindre
        </Button>
      </Upload>
    );
  }
}
