import React, { Component } from 'react';
import styled from '@emotion/styled';
import { Typography, Descriptions } from 'antd';

class detailAdherent extends Component {

  fetchAdherent = (pagination = {}) => {
    const { dispatch } = this.props;

    dispatch({
      type: `detailLaboratoire/fetchBaremes`,
      payload: { values: this.searchValues, frontPagination: pagination },
    });
  };

  render() {
    const { Title } = Typography;
    return (
      <Bloc>
        <Title level={3}>Demande d'une prise en charge</Title>
        <Descriptions bordered>
          <Descriptions.Item label="N° Police">
            5 19522457
            <br />{' '}
          </Descriptions.Item>
          <Descriptions.Item label="Raison sociale:">
            LLLLLL
            <br />
          </Descriptions.Item>
          <Descriptions.Item label="N° affiliation">62369854-652</Descriptions.Item>
          <Descriptions.Item label="Date demande:">14/19/2019</Descriptions.Item>
          <Descriptions.Item label="Assuré Prénom & Nom:">5 19522457</Descriptions.Item>
          <Descriptions.Item label="Bénéficiare Prénom & Nom">LLLLLL</Descriptions.Item>
          <Descriptions.Item label="Rang">Fils</Descriptions.Item>
          <Descriptions.Item label="N° CIN">BL 587496</Descriptions.Item>
        </Descriptions>
      </Bloc>
    );
  }
}

const Bloc = styled.div`
    padding: 10px;
    border: 1px solid #afafb1;
    border-radius: 4px;
`;

export default detailAdherent;
