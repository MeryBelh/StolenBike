import React, { Component } from 'react';
import styled from '@emotion/styled';
import { Typography, Row, Select, Form, DatePicker, Input } from 'antd';

class DetailPrestation extends Component {
  handleChange = value => {
    console.log(`selected ${value}`);
  };

  onChange = (date, dateString) => {
    console.log(date, dateString);
  };

  render() {
    const { Title } = Typography;
    const { Option } = Select;
    const InputGroup = Input.Group;
    return (
      <Layout>
        <br />
        <Title level={4}>
          <u>Veuillez renseigner le détail de la prestation:</u>
        </Title>
        <Bloc>
          <Form.Item label="Pathologie" required>
            <Select defaultValue="Pathologie" onChange={this.handleChange}>
              <Option value="Pathologie">Pathologie</Option>
              <Option value="Pathologie2">Pathologie2</Option>
              <Option value="Pathologie3">Pathologie3</Option>
              <Option value="Pathologie3">Pathologie3</Option>
            </Select>
          </Form.Item>
          <Form.Item label="Date consultation">
            <DatePicker onChange={this.onChange} />
          </Form.Item>
          <Form.Item label="Médecin traitant:">
            <Input placeholder="Médecin traitant" />
          </Form.Item>
          <Form.Item label="Téléphone:">
            <Input placeholder="06 60 00 00 00" />
          </Form.Item>
          <Form.Item label="Email assuré:">
            <Input placeholder="email@test.com" />
          </Form.Item>
        </Bloc>
      </Layout>
    );
  }
}

const Bloc = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  p {
  }
`;

const Layout = styled.div`
    padding: 10px;
    border: 1px solid #afafb1;
    border-radius: 4px;
    margin-top: 40px;
`

export default DetailPrestation;
