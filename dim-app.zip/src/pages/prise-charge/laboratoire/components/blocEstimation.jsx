import React, { Component } from 'react';
import { Table, Select, Button } from 'antd';
import styled from '@emotion/styled';

class blocEstimation extends Component {

  state = {
    type: null,
    estimation: [],
    somme: 0
  }
  handleChange = (value) => {
    this.setState({
      type: value
    })
  }

  hangleEstimation = () => {
    if(this.state.type){
      this.props.baremes.content.filter(bareme => bareme.codeSousActe === this.state.type)
        .map(bareme => (
          this.setState(prevState => ({
            estimation: [...this.state.estimation, {
              analyses: bareme.libelleSousActe,
              cotation: bareme.cotation,
              estimation: bareme.montant,
              codeBareme: bareme.codeBareme
            }],
            somme: prevState.somme + bareme.montant
          })
          )
        ))
    }
  }

  handleDelete = (id, obj) => {
    const estimation = this.state.estimation.filter(item => {
      //this.setState(prevState => ({
       // somme: prevState.somme - item.estimation
      //}))
      console.log('item.estimation8888', item)

     return item.codeBareme !== id

    })
    this.setState({
      estimation,
    })
  }

  render() {
    const { Option } = Select;
    console.log('type', this.state.type)
    const columns = [
      {
        title: 'Analyses',
        dataIndex: 'analyses',
        key: 'analyses',
      },
      {
        title: 'Cotation',
        dataIndex: 'cotation',
        key: 'cotation',
      },
      {
        title: 'Estimation des couts',
        dataIndex: 'estimation',
        key: 'estimation',
      },
      {
        title: 'Action',
        dataIndex: 'codeBareme',
        key: 'x',
        render: (id, obj) => <a href="javascript:;" onClick={() => this.handleDelete(id, obj)}>Delete</a>,
      },
    ];
    console.log('this.props', this.props)
    return (
      <Bloc>
        <div className="estimationHeader">
          <Select style={{ width: 120 }} onChange={this.handleChange}>
            {
              this.props.baremes.content && this.props.baremes.content.map((bareme, index) => <Option value={bareme.codeSousActe} key={index}>{bareme.libelleSousActe}</Option>)
            }
          </Select>
          <Button type="primary" onClick={() => this.hangleEstimation()}>Ajouter</Button>
        </div>
        <Table dataSource={this.state.estimation} columns={columns} />
        <p className="textRight">Total Estimation: <b>{this.state.somme} somme totale (Dhs)</b></p>
      </Bloc>
    )
  }
}

const Bloc = styled.div`
    padding: 10px;
    border: 1px solid #afafb1;
    border-radius: 4px;
    margin-top: 40px;
    .estimationHeader{
       text-align: right;
       margin-bottom: 15px;
       button{
          margin-left: 8px;
       }
    }
    .textRight{
       text-align: right;
    }
`

export default blocEstimation;
