import React, { Component } from 'react';
import DetailAdherent from './detailAdherent';
import DetailPrestation from './detailPrestation';
import BlocEstimation from './blocEstimation';
import Observations from '../../components/observations';
import UploadFile from '../../components/uploadFile';

class pageLaboratoire extends Component{

  componentDidMount() {
    this.fetchData();
  }

  fetchData = () => {
    const {dispatch} = this.props;
    dispatch({ type: 'detailLaboratoire/fetchBaremes', payload: { numero: "123456" } });
  };

  render() {
    console.log('this.props', this.props)
    return(
      <>
        <DetailAdherent />
        <DetailPrestation />
        <BlocEstimation baremes={this.props.baremes} />
        <Observations />
        <UploadFile />
      </>
    )
  }
}

export default pageLaboratoire;
