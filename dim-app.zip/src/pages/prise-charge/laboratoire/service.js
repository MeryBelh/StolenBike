import request from '@/utils/request';

export function fetchBaremes(numeroAdherent) {
  return request(`/baremes/${numeroAdherent}`);
}
