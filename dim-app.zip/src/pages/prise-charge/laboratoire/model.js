import { detailLaboratoire, fetchBaremes } from './service';

export default {
  namespace: 'detailLaboratoire',
  state: {
    adherents: { data: [] },
    baremes: { data: [] }
  },
  effects: {
    *fetchBaremes({ payload }, { call, put }) {
      console.log('fetchBaremes')
      try {
        const { numero } = payload;
        const baremes = yield call(fetchBaremes, numero);
        yield put({
          type: 'baremesFetch',
          payload: baremes,
        });
      } catch (e) {
        console.log(e);
      }
    },
  },

  reducers: {
    baremesFetch(state, action) {
      return {
        ...state,
        baremes: action.payload,
      };
    },
  },
};
