import { connect } from 'dva';
import PageLaboratoire from './components/pageLaboratoire';
const mapStateToProps = ({ detailLaboratoire }) => ({
  baremes: detailLaboratoire.baremes
});

export default connect(mapStateToProps)(PageLaboratoire);
