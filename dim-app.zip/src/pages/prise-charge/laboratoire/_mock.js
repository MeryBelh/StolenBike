import mockjs from 'mockjs';

const baremes = mockjs.mock({
  'content|100': [
    {
      'codeBareme|1-1000': 0,
      codeActe: 0,
      'codeSousActe|1-1000': 0,
      libelleSousActe: "test",
      codeSousActePrincipal: 0,
      'montant|1-10000': 0,
      typeBareme: "test",
      typePrestataire: "test",
      typeTarif: "test",
      regle: "test",
      codeMetier: "test",
      visionOeil: "test",
      cotation: "test"
    }
  ],
});

export default {
  'GET /mock/baremes/123456': baremes,
};
