import decode from 'jwt-decode';
import moment from 'moment';
import { setAuthority, deleteAuthority } from './authority';

function* persistTokenInformation(token) {
  const { access_token, expires_in } = token;
  const { authorities } = decode(access_token);
  setAuthority(authorities);
  yield localStorage.setItem('access-token', JSON.stringify(access_token));
  yield localStorage.setItem(
    'token-valid-until',
    JSON.stringify(moment().valueOf() + expires_in * 1000),
  );
}

function deleteTokenInformation() {
  console.log('logout');
  localStorage.removeItem('token-valid-until');
  localStorage.removeItem('access-token');
  deleteAuthority();
}

const getAccessToken = () => {
  const validUntil = localStorage.getItem('token-valid-until') || 0;

  const now = moment().valueOf();
  const accessToken = JSON.parse(localStorage.getItem('access-token'));
  console.log('validUntil', validUntil);
  console.log('now', now);
  console.log('now < validUntil', now < validUntil);
  if (now < validUntil && accessToken) {
    console.log('accessToken', accessToken);
    return accessToken;
  }

  deleteTokenInformation();
  return null;
};

export { persistTokenInformation, getAccessToken, deleteTokenInformation };
