import request from '@/utils/request';
import { FromDataType } from './index';

export async function fetchToken(params: FromDataType) {
  const { userName, password} = params

  console.log(`username: ${userName}, password: ${password}`)

  return request('http://192.168.1.236:8088/oauth/token', {
    prefix: '',
    method: 'POST',
    body : `username=${userName}&password=${password}&grant_type=password`,
    headers: { "Content-Type": "application/x-www-form-urlencoded",
      "Authorization": "Basic d2ZhLndhLmRpbTpBc2MyNTVQZHM="},
  });
}

export async function refreshToken(token: string)
{
  return request('/login/refreshToken', {
    method: 'POST',
    body : `token=${token}`,
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
  });
}
