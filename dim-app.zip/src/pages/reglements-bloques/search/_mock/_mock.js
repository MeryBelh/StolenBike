import mockjs from 'mockjs';

const { data } = mockjs.mock({
  'data|100': [
    {
      'categorie|0-100': 0,
      'police|0-100': 0,
      client: 'client1',
      date: '01/01/2019',
      'montant|1000-10000': 0,
    },
  ],
});

export default {
  'POST /api/blockedPayement': data,
};
