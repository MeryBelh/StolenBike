import { applyPolicy } from '../../../utils/utils';

const reglementBloqueMapper = applyPolicy([
  {
    label: 'Catégorie',
    name: 'categorie',
    key: 'categorie',
    sorter: (a, b) => a.categorie - b.categorie,
  },
  {
    label: 'Police',
    name: 'numeroContrat',
    key: 'numeroContrat',
  },
  {
    label: 'Client',
    name: 'nomClient',
    key: 'nomClient',
  },
  {
    label: 'Date',
    name: 'dateSaisie',
    key: 'dateSaisie',
    //render: text => <span>{text ? 'Male' : 'Female'}</span>,
  },
  {
    label: 'Montant',
    name: 'montant',
    key: 'montant',
  },
]);
export default reglementBloqueMapper;
