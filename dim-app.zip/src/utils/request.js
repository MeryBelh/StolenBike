/**
 * request 网络请求工具
 * 更详细的 api 文档: https://github.com/umijs/umi-request
 */
import { extend } from 'umi-request';
import { notification } from 'antd';
import { getAccessToken } from '../pages/user/login/utils/utils';

const codeMessage = {
  200: 'The server successfully returned the requested data.',
  201: 'New or modified data is successful.',
  202: 'A request has entered the background queue (asynchronous task).',
  204: 'The data was deleted successfully.',
  400: 'The request was made with an error and the server did not perform any operations to create or modify data.',
  401: 'User does not have permission (token, username, password is incorrect).',
  403: 'The user is authorized, but access is forbidden.',
  404: 'The request is made for a record that does not exist and the server does not operate.',
  406: 'The format of the request is not available.',
  410: 'The requested resource is permanently deleted and will not be retrieved.',
  422: 'A validation error occurred when creating an object.',
  500: 'An error occurred on the server. Please check the server.',
  502: 'Gateway error.',
  503: 'The service is unavailable and the server is temporarily overloaded or maintained.',
  504: 'The gateway timed out.',
};
/**
 * 异常处理程序
 */

const errorHandler = error => {
  console.log(error);
  const {
    response = {},
    data: { message },
  } = error;
  const { status } = response;

  if (message && (status === 400 || status === 404)) {
    notification.error({ message });
  }
};
/**
 * 配置request请求时的默认参数
 */

const rootUrls = {
  mock: 'http://localhost:8000/mock',
  local: 'http://192.168.112.109:8063',
  remote: 'http://192.168.1.236:8765/wa/api/v1/dim',
};
const token =
  'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJtb3NhZGlhbGlvdStpbnRlZzAwQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJ1c2VyX2lkIjo1NjQxLCJ1c2VyX25hbWUiOiJtb3NhZGlhbGlvdStpbnRlZzAwQGdtYWlsLmNvbSIsImlkZW50aXR5IjpbXSwic2NvcGUiOlsiZGltOioiLCJ1YWE6YXBpOnJlZ2lzdGVyIiwidWFhOmFwaToqIiwidWFnOioiXSwiaXNzIjoid2ZhOnVhYTpkaWdpdGFsLXVzZXIiLCJleHAiOjE1NjQ1NjA5MDQsImF1dGhvcml0aWVzIjpbIlJPTEVfQ0xJRU5UIl0sImp0aSI6ImFiOWRkNzVmLTJiYWUtNDkzZC1hODVjLWI4ZjliOTlhODAzNiIsImVtYWlsIjoibW9zYWRpYWxpb3UraW50ZWcwMEBnbWFpbC5jb20iLCJjbGllbnRfaWQiOiJ3ZmEud2EuZGltIn0.pm_4C2uX4R7O21w_aYDotAgt9lYCE7d7QSOqK8Qpf4LJzXPkJjgCF_t7G6O1OVIynfX3nGt6CmN2G5KBvAS2JM-qiFQJbaFimnqRtgrz3tlPHG-SZwai9bV9Zk-LJuUYI4XqFfgPnJP7q_fUwakbG22AdZgdyWrSxr1yk4a3ZpeXVdbxymk0Z6OpaPVB8eZbLpyJwODx4or7YaEn84jHhMsGFt_HvO1wbPlv5Tuv5A-YaLg3oWeC8KRm226PmxuMf11qsscKxX-YyOjzJCMhm9madE2dVF2C5jvYSXEpXiKBP0JCvuRKdbImMVEJ7fnJs7Un9p70gF6ohz0JWzFBFw';

const request = extend({
  errorHandler,
  prefix: rootUrls.mock,
  headers: { Authorization: `Bearer ${getAccessToken()}` },
  // 默认错误处理
  // TODO : remove this comment
  // credentials: 'include', // 默认请求是否带上cookie
});

export default request;
